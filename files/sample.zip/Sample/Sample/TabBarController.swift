//
//  TabBarController.swift
//  Sample
//
//  Created by Carlos Ruiz on 7/8/17.
//  Copyright © 2017 Carlos Ruiz. All rights reserved.
//

import UIKit

class TabBarController: UITabBarController {

    override func viewDidLoad() {
        super.viewDidLoad()

        // Do any additional setup after loading the view.
    }

    override func didReceiveMemoryWarning() {
        super.didReceiveMemoryWarning()
        // Dispose of any resources that can be recreated.
    }
    
    func isIPad() -> Bool {
        if UIDevice.current.userInterfaceIdiom == .pad {
            return true
        }
        return false
    }
    
    override var shouldAutorotate: Bool {
        if isIPad() {
            return true
        }
        
        return false
    }
    
    override var supportedInterfaceOrientations: UIInterfaceOrientationMask {
        if isIPad() {
            return UIInterfaceOrientationMask.landscape
        }
        
        return UIInterfaceOrientationMask.portrait
    }    
}
