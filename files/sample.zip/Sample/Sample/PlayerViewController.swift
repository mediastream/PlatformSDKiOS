//
//  PlayerViewController.swift
//  Sample
//
//  Created by Carlos Ruiz on 7/8/17.
//  Copyright © 2017 Carlos Ruiz. All rights reserved.
//

import UIKit
import MediastreamPlatformSDK

class PlayerViewController: UIViewController {

    @IBOutlet weak var containerView: UIView!
    let playerConfig = MediastreamPlayerConfig()
    let mdstrm = MediastreamPlatformSDK()
    var fullscreen = false
    
    override func viewWillDisappear(_ animated: Bool) {
        super.viewWillDisappear(animated)
        mdstrm.releasePlayer()
    }
    
    override func viewDidAppear(_ animated: Bool) {
        viewDidLoad()
    }
    
    override func viewDidLoad() {
        super.viewDidLoad()

        playerConfig.accountID = "58506dba84c55d1f3828147c"
        playerConfig.type = MediastreamPlayerConfig.VideoTypes.VOD
        playerConfig.id = "58595caab14211327db6d252"
        playerConfig.environment = MediastreamPlayerConfig.Environments.QA
        
        mdstrm.view.translatesAutoresizingMaskIntoConstraints = false
        mdstrm.view.frame = containerView.bounds
        containerView.addSubview(mdstrm.view)
        
        self.addChildViewController(mdstrm)
        mdstrm.didMove(toParentViewController: self)
        
        mdstrm.setup(playerConfig)
        mdstrm.play()
        self.navigationItem.rightBarButtonItem = UIBarButtonItem(title: "Present Modally", style: .plain, target: self, action: #selector(pushModally))
        mdstrm.events.listenTo(eventName: "offFullScreen") {
            if self.isIPad() {
                if UIInterfaceOrientation.portrait.isPortrait {}
                UIDevice.current.setValue(Int(UIInterfaceOrientation.landscapeRight.rawValue), forKey: "orientation")
            } else {
                UIDevice.current.setValue(Int(UIInterfaceOrientation.portrait.rawValue), forKey: "orientation")
            }
        }
    }
    
    func pushModally() {
        self.performSegue(withIdentifier: "presentModally", sender: nil)
        mdstrm.pause()
    }
    
    func isIPad() -> Bool {
        if UIDevice.current.userInterfaceIdiom == .pad {
            return true
        }
        return false
    }
    
    override var shouldAutorotate: Bool {
        if isIPad() {
            return true
        }
        
        return false
    }
    
    override var supportedInterfaceOrientations: UIInterfaceOrientationMask {
        if isIPad() {
            return UIInterfaceOrientationMask.landscape
        }
        
        return UIInterfaceOrientationMask.portrait
    }
    
    override func didReceiveMemoryWarning() {
        super.didReceiveMemoryWarning()
        // Dispose of any resources that can be recreated.
    }
    
    override func viewDidLayoutSubviews() {
        super.viewDidLayoutSubviews()
        if view.bounds != mdstrm.view?.bounds {
            UIDevice.current.setValue(Int(UIInterfaceOrientation.portrait.rawValue), forKey: "orientation")
        }
    }    
}
